#include "stdafx.h"
#include "playerData.h"

// �ʱ�ȭ (init)
HRESULT playerData::init()
{
	return S_OK;
}

// ���� (release)
void playerData::release()
{
}
