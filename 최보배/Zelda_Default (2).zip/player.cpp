#include "stdafx.h"
#include "player.h"

HRESULT player::init()
{

	_inventory = new Inventory;
	_inventory->init();

	_playercenter.x = WINSIZEX / 2;
	_playercenter.y = WINSIZEY / 2;

	_playerImage = IMAGEMANAGER->addImage("�÷��̾�ո��", "�÷��̾�/��ũ�ո��.bmp", 64, 64, true, RGB(255, 0, 255));
	_playerLeft = IMAGEMANAGER->addFrameImage("�÷��̾�����̵�", "�÷��̾�/��ũ�����ΰȱ�_230+23_10��.bmp", 640, 64, 10, 1);
	_playerRight = IMAGEMANAGER->addFrameImage("�÷��̾�������̵�", "�÷��̾�/��ũ�����ʿ����ΰȱ�_230+23_10��.bmp", 640, 64, 10, 1);
	_playerUp = IMAGEMANAGER->addFrameImage("�÷��̾������̵�", "�÷��̾�/��ũ���ΰȱ�_180+26_10��.bmp", 640, 64, 10, 1);
	_playerDown = IMAGEMANAGER->addFrameImage("�÷��̾�Ʒ����̵�", "�÷��̾�/��ũ�����ΰȱ�_180+24_10��.bmp", 640, 64, 10, 1);

	_playerLeftatk = IMAGEMANAGER->addFrameImage("�÷��̾���ʰ���", "�÷��̾�/��ũ�����ΰ���_609+25_29��.bmp", 2320, 80, 29, 1);
	_playerRightatk = IMAGEMANAGER->addFrameImage("�÷��̾�����ʰ���", "�÷��̾�/��ũ�����ʿ����ΰ���_609+25_29��.bmp", 2320, 80, 29, 1);
	_playerUpatk = IMAGEMANAGER->addFrameImage("�÷��̾����ʰ���", "�÷��̾�/��ũ�ڷΰ���_638+28_11��.bmp", 880, 80, 11, 1);
	_playerFrontatk = IMAGEMANAGER->addFrameImage("�÷��̾���ʰ���", "�÷��̾�/��ũ�����ΰ���_209+24_11��.bmp", 880, 80, 11, 1);

	
	_playerRc = RectMakeCenter(_playercenter.x, _playercenter.y, 64, 64);

	
	_left = false;
	_right = false;
	_up = false;
	_down = false;

	_leftatk = false;
	_rightatk = false;
	_upatk = false;
	_frontatk = false;

	_count = _index = 0;

	return S_OK;
}

void player::release()
{
	_inventory->release();
	SAFE_DELETE(_inventory);
}

void player::update()
{
	_state = IDLE;

	if (INPUT->getKey(VK_LEFT) && _playerRc.left >= 0)
	{
		_left = true;
		_state = LEFT;

		_playerRc.left -= 3;
		_playerRc.right -= 3;
		if (INPUT->getKey(VK_SPACE))
		{
			_leftatk = true;
			_state = LEFTATK;
		}
	}


	else if (INPUT->getKey(VK_RIGHT) && _playerRc.right <= WINSIZEX )
	{
		_right = true;
		_state = RIGHT;
		_playerRc.left += 3;
		_playerRc.right += 3;
		if (INPUT->getKey(VK_SPACE))
		{
			_rightatk = true;
			_state = RIGHTATK;
		}
	}


	else if (INPUT->getKey(VK_UP) && _playerRc.top >= 0)
	{
		_up = true;
		_state = UP;

		_playerRc.top -= 3;
		_playerRc.bottom -= 3;
		if (INPUT->getKey(VK_SPACE))
		{
			_upatk = true;
			_state = UPATK;
		}
	}


	else if (INPUT->getKey(VK_DOWN) && _playerRc.bottom <= WINSIZEY)
	{
		_down = true;
		_state = DOWN;
		_playerRc.top += 3;
		_playerRc.bottom += 3;
		if (INPUT->getKey(VK_SPACE))
		{
			_frontatk = true;
			_state = FRONTATK;
		}
	}

	this->animation();


	_inventory->update();
}

void player::render()
{

	Rectangle(getMemDC(), _playerRc);
	if (_state == IDLE)
	{
		_playerImage->render(getMemDC(), _playerRc.left, _playerRc.top);
	}
	if (_state == LEFT)
	{
		_playerLeft->frameRender(getMemDC(), _playerRc.left, _playerRc.top);
	}
	if (_state == RIGHT)
	{
		_playerRight->frameRender(getMemDC(), _playerRc.left, _playerRc.top);
	}
	if (_state == UP)
	{
		_playerUp->frameRender(getMemDC(), _playerRc.left, _playerRc.top);
	}
	if (_state == DOWN)
	{
		_playerDown->frameRender(getMemDC(), _playerRc.left, _playerRc.top);
	}



	//======================������� �̵�====================================//
	if (_state == LEFTATK)
	{
		_playerLeftatk->frameRender(getMemDC(), _playerRc.left - 20, _playerRc.top - 15);
	}
	if (_state == RIGHTATK)
	{
		_playerRightatk->frameRender(getMemDC(), _playerRc.left + 10, _playerRc.top - 10);
	}
	if (_state == UPATK)
	{
		_playerUpatk->frameRender(getMemDC(), _playerRc.left - 10, _playerRc.top - 15);
	}
	if (_state == FRONTATK)
	{
		_playerFrontatk->frameRender(getMemDC(), _playerRc.left - 10, _playerRc.top);
	}

	_inventory->render();
}



void player::animation()
{
	switch (_state)
	{

	case IDLE:

		_playerImage->render(getMemDC(), _playerRc.left, _playerRc.top);

		break;

	case LEFT:

		if (_left)
		{
			_count++;
			_playerLeft->setFrameY(0);
			if (_count % 10 == 0)
			{
				_index++;

				if (_index >= 10)
				{
					_index = 0;
				}
				_playerLeft->setFrameX(_index);
			}
		}
		break;
	case RIGHT:

		if (_right)
		{
			_count++;
			_playerRight->setFrameY(0);
			if (_count % 10 == 0)
			{
				_index++;

				if (_index >= 10)
				{
					_index = 0;
				}
				_playerRight->setFrameX(_index);
			}
		}
		break;
	case UP:

		if (_up)
		{
			_count++;
			_playerUp->setFrameY(0);
			if (_count % 10 == 0)
			{
				_index++;

				if (_index >= 10)
				{
					_index = 0;
				}
				_playerUp->setFrameX(_index);
			}
		}
		break;
	case DOWN:

		if (_down)
		{
			_count++;
			_playerDown->setFrameY(0);
			if (_count % 10 == 0)
			{
				_index++;

				if (_index >= 10)
				{
					_index = 0;
				}
				_playerDown->setFrameX(_index);
			}
		}
		break;


		//================================================================������� �̵�==================================================================//



	case LEFTATK:

		if (_leftatk)
		{
			_count++;
			_playerLeftatk->setFrameY(0);
			if (_count % 3 == 0)
			{
				_index++;

				if (_index >= 29)
				{
					_index = 0;
				}
				_playerLeftatk->setFrameX(_index);
			}
		}
		break;
	case RIGHTATK:

		if (_rightatk)
		{
			_count++;
			_playerRightatk->setFrameY(0);

			if (_count % 3 == 0)
			{
				_index++;

				if (_index >= 29)
				{
					_index = 0;
				}
				_playerRightatk->setFrameX(_index);
			}
		}
		break;
	case UPATK:

		if (_upatk)
		{
			_count++;
			_playerUpatk->setFrameY(0);

			if (_count % 3 == 0)
			{
				_index++;

				if (_index >= 11)
				{
					_index = 0;
				}
				_playerUpatk->setFrameX(_index);
			}
		}
		break;

	case FRONTATK:

		if (_frontatk)
		{
			_count++;
			_playerFrontatk->setFrameY(0);

			if (_count % 5 == 0)
			{
				_index++;

				if (_index >= 11)
				{
					_index = 0;
				}
				_playerFrontatk->setFrameX(_index);
			}
		}
		break;
	}
}