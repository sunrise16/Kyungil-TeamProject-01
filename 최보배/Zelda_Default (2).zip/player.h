#pragma once
#include "gameNode.h"
#include "Inventory.h"

enum STATE
{
	IDLE,
	LEFT,
	RIGHT,
	UP,
	DOWN,
	LEFTATK,
	RIGHTATK,
	UPATK,
	FRONTATK
};

class player : public gameNode
{
private:

	Inventory* _inventory;
	
	POINT _playercenter;
	RECT _playerRc;

	

	image* _playerImage;
	image* _playerLeft;
	image* _playerRight;
	image* _playerUp;
	image* _playerDown;
	image* _playerLeftatk;
	image* _playerRightatk;
	image* _playerUpatk;
	image* _playerFrontatk;


	image* _playerHp;

	STATE _state;


	bool _left;
	bool _right;
	bool _up;
	bool _down;
	bool _leftatk;
	bool _rightatk;
	bool _upatk;
	bool _frontatk;

	int _count;
	int _index;
	
public:

	// �ʱ�ȭ ó��
	HRESULT init();

	// ���� ó��
	void release();

	// ���� ó��
	void update();

	// ȭ�� ��� ó��
	void render();

	void animation();



	player() {}
	~player() {}
};

